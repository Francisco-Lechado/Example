-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 25-11-2020 a las 21:50:11
-- Versión del servidor: 10.4.14-MariaDB
-- Versión de PHP: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tienda`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `Nombre` varchar(20) NOT NULL,
  `Apellidos` varchar(30) NOT NULL,
  `Direccion` varchar(20) NOT NULL,
  `Dni` varchar(9) NOT NULL,
  `Telefono` int(9) DEFAULT NULL,
  `Email` varchar(20) DEFAULT NULL,
  `Pedido` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`ID`, `Nombre`, `Apellidos`, `Direccion`, `Dni`, `Telefono`, `Email`, `Pedido`) VALUES
(2, 'Juan', 'Perez', 'C/Torres', '45721922F', 994325127, 'juanPerez@gmail.com', 'a:5:{s:3:\"Pan\";s:1:\"1\";s:6:\"Banana\";s:1:\"1\";s:8:\"HKC 16M4\";s:1:\"1\";s:28:\"Chaise longue reversible ZIP\";s:1:\"1\";s:4:\"Pera\";s:1:\"1\";}');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `Nombre` varchar(30) NOT NULL,
  `Stock` int(4) UNSIGNED NOT NULL,
  `Precio` float UNSIGNED NOT NULL,
  `Inf.Adicional` varchar(50) DEFAULT NULL,
  `Clase` enum('Alimentario','Electronica','Hogar','Miscelanea') NOT NULL DEFAULT 'Miscelanea',
  `Empresa` varchar(30) DEFAULT NULL,
  `Tag` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`ID`, `Nombre`, `Stock`, `Precio`, `Inf.Adicional`, `Clase`, `Empresa`, `Tag`) VALUES
(1, 'Manzana', 35, 3.5, 'Caja, 1.5 kg', 'Alimentario', 'Carrefour', 'Fruta'),
(2, 'Pera', 25, 2.5, 'Caja, 1.200 kg', 'Alimentario', 'Carrefour', 'Fruta'),
(3, 'Pan', 22, 0.55, 'Barra', 'Alimentario', 'Carrefour', NULL),
(4, 'HKC 16M4', 12, 89.99, '15.6\", USB 2.0', 'Electronica', 'Amazon', 'Tv'),
(5, 'Photosmart 5520', 12, 79.5, 'Impresora con scanner', 'Electronica', 'HP', 'Impresora, Scan'),
(6, 'Banana', 12, 1.8, 'Caja 1kg', 'Alimentario', 'Carrefour', 'Fruta'),
(7, 'Chaise longue reversible ZIP', 3, 319, 'Lado de la chaise longue reversible', 'Hogar', 'Conforama', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `Empresa` varchar(20) NOT NULL,
  `Nombre representante` varchar(30) NOT NULL,
  `Telefono representante` int(9) UNSIGNED NOT NULL,
  `Email representante` varchar(25) DEFAULT NULL,
  `Tipo de productos` enum('Alimentarios','Electronica','Hogar','Miscelanea') NOT NULL DEFAULT 'Miscelanea'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`ID`, `Empresa`, `Nombre representante`, `Telefono representante`, `Email representante`, `Tipo de productos`) VALUES
(1, 'Carrefour', 'Pedro Ramirez', 98467295, 'PedroCarrefour@gmail.es', 'Alimentarios'),
(2, 'HP', 'Ignacio Sanchez', 99465218, 'IganacioHP@gmail.es', 'Electronica'),
(3, 'Amazon', 'Juan Jimenez', 976424566, 'JuAmazon@gmail.es', 'Miscelanea'),
(4, 'Conforama', 'Maria Marquez', 992172031, 'MMConforama@gmail.es', 'Hogar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `Usuario` varchar(20) NOT NULL,
  `Contraseña` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`Usuario`, `Contraseña`) VALUES
('admin', '1234A');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`),
  ADD UNIQUE KEY `Nombre` (`Nombre`),
  ADD KEY `fk_empresa` (`Empresa`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`),
  ADD UNIQUE KEY `Empresa` (`Empresa`),
  ADD UNIQUE KEY `Telefono representante` (`Telefono representante`),
  ADD UNIQUE KEY `Email representante` (`Email representante`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`Usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `fk_empresa` FOREIGN KEY (`Empresa`) REFERENCES `proveedores` (`Empresa`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
